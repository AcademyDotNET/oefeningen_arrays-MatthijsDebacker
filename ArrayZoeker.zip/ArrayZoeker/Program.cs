﻿using System;

namespace ArrayZoeker
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = AskForInt("Please give a number.");
            }

            int number = AskForInt("Please give a number to remove from the list: ");

            bool found = false;

            for (int i = 0; i < arr.Length; i++)
            {
                if(found)
                {
                    if(i == arr.Length - 1)
                    {
                        arr[i] = -1;
                    }
                    else
                    {
                        arr[i] = arr[i + 1];
                    }
                }
                else if(number == arr[i] && found == false)
                {
                    arr[i] = arr[i + 1];
                    found = true;
                }
            }

            Console.WriteLine();
            Console.WriteLine("The list is now: ");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($" {arr[i]} ");
            }
        }

        static int AskForInt(string question)
        {
            Console.WriteLine(question);
            int input = 0;

            string sInput = Console.ReadLine();
            while (!int.TryParse(sInput, out input))
            {
                Console.WriteLine("Invalid number, please try again");
                sInput = Console.ReadLine();
            }

            return input;
        }
    }
}
